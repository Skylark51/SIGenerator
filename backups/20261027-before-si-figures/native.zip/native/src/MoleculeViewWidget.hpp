#pragma once

#include "si/GaussianParser.hpp"

#include <QOpenGLWidget>
#include <QPointF>
#include <QVector>

class MoleculeViewWidget final : public QOpenGLWidget {
  Q_OBJECT
public:
  enum class InteractionMode { View, SpinDensity, Geometry };

  explicit MoleculeViewWidget(QWidget* parent = nullptr);
  void setMolecule(const std::vector<si::Atom>& atoms, const std::vector<si::SpinDensity>& spins, const std::string& spinBasisLevel="unknown", bool spinFallback=false);
  void clearMolecule();
  void setInteractionMode(InteractionMode mode);
  [[nodiscard]] InteractionMode interactionMode() const { return mode_; }
  void setAtomIndicesVisible(bool visible);
  [[nodiscard]] bool atomIndicesVisible() const { return showIndices_; }
  void resetView();
  void clearSelection();
  [[nodiscard]] QVector<int> selectedAtoms() const { return selectedAtoms_; }

signals:
  void atomPicked(int atomIndex, const QString& element, double spinDensity, bool hasSpinDensity);
  void geometrySelectionChanged(const QVector<int>& atomIndices);

protected:
  void initializeGL() override;
  void paintGL() override;
  void resizeGL(int width, int height) override;
  void mousePressEvent(QMouseEvent* event) override;
  void mouseMoveEvent(QMouseEvent* event) override;
  void mouseReleaseEvent(QMouseEvent* event) override;
  void wheelEvent(QWheelEvent* event) override;

private:
  struct ProjectedAtom { QPointF point; double depth{}; double radius{}; int index{}; };
  struct Bond { int first{}; int second{}; };
  [[nodiscard]] QVector<ProjectedAtom> projectedAtoms() const;
  [[nodiscard]] int pickAtom(const QPointF& position) const;
  void rebuildBonds();
  void handleClick(const QPointF& position);

  std::vector<si::Atom> atoms_;
  std::vector<si::SpinDensity> spins_;
  std::string spinBasisLevel_{"unknown"};
  bool spinFallback_{};
  QVector<Bond> bonds_;
  QVector<int> selectedAtoms_;
  InteractionMode mode_{InteractionMode::View};
  bool showIndices_{true};
  QPoint lastMouse_;
  bool dragging_{};
  bool moved_{};
  Qt::MouseButton dragButton_{Qt::NoButton};
  double yaw_{-25.0};
  double pitch_{20.0};
  double zoom_{1.0};
  QPointF pan_;
};
