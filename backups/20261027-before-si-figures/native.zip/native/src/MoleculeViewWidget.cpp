#include "MoleculeViewWidget.hpp"

#include <QMouseEvent>
#include <QPainter>
#include <QLineF>
#include <QWheelEvent>
#include <algorithm>
#include <cmath>
#include <numbers>

namespace {
QColor elementColor(const std::string& symbol) {
  if (symbol == "H") return QColor(238, 238, 238);
  if (symbol == "C") return QColor(70, 75, 82);
  if (symbol == "N") return QColor(50, 90, 220);
  if (symbol == "O") return QColor(220, 55, 45);
  if (symbol == "F" || symbol == "Cl") return QColor(55, 185, 80);
  if (symbol == "S") return QColor(225, 185, 45);
  if (symbol == "P") return QColor(235, 135, 45);
  if (symbol == "Fe") return QColor(205, 110, 50);
  if (symbol == "Co") return QColor(225, 105, 135);
  if (symbol == "Ni") return QColor(80, 175, 80);
  if (symbol == "Cu") return QColor(185, 105, 50);
  if (symbol == "Zn") return QColor(130, 130, 180);
  return QColor(120, 155, 190);
}

double covalentRadius(int atomicNumber) {
  switch (atomicNumber) {
  case 1: return 0.31; case 6: return 0.76; case 7: return 0.71; case 8: return 0.66;
  case 9: return 0.57; case 14: return 1.11; case 15: return 1.07; case 16: return 1.05;
  case 17: return 1.02; case 26: return 1.32; case 27: return 1.26; case 28: return 1.24;
  case 29: return 1.32; case 30: return 1.22; case 35: return 1.20;
  default: return 0.85;
  }
}
}

MoleculeViewWidget::MoleculeViewWidget(QWidget* parent) : QOpenGLWidget(parent) {
  setObjectName(QStringLiteral("moleculeView"));
  setMinimumSize(320, 260);
  setFocusPolicy(Qt::StrongFocus);
  setToolTip(tr("왼쪽 드래그: 회전, 오른쪽 드래그: 이동, 휠: 확대/축소 (Drag: rotate/pan, wheel: zoom)"));
}

void MoleculeViewWidget::setMolecule(const std::vector<si::Atom>& atoms, const std::vector<si::SpinDensity>& spins, const std::string& spinBasisLevel, bool spinFallback) {
  atoms_ = atoms; spins_ = spins; spinBasisLevel_=spinBasisLevel;spinFallback_=spinFallback;selectedAtoms_.clear(); rebuildBonds(); resetView(); update();
}
void MoleculeViewWidget::clearMolecule() { atoms_.clear(); spins_.clear();spinBasisLevel_="unknown";spinFallback_=false;bonds_.clear(); selectedAtoms_.clear(); update(); }
void MoleculeViewWidget::setInteractionMode(InteractionMode mode) { mode_ = mode; selectedAtoms_.clear(); emit geometrySelectionChanged(selectedAtoms_); update(); }
void MoleculeViewWidget::setAtomIndicesVisible(bool visible) { showIndices_ = visible; update(); }
void MoleculeViewWidget::resetView() { yaw_=-25.0; pitch_=20.0; zoom_=1.0; pan_={}; update(); }
void MoleculeViewWidget::clearSelection() { selectedAtoms_.clear(); emit geometrySelectionChanged(selectedAtoms_); update(); }
void MoleculeViewWidget::initializeGL() {}
void MoleculeViewWidget::resizeGL(int, int) {}

QVector<MoleculeViewWidget::ProjectedAtom> MoleculeViewWidget::projectedAtoms() const {
  QVector<ProjectedAtom> output; if (atoms_.empty()) return output;
  std::array<double,3> center{}; for (const auto& atom : atoms_) for(int i=0;i<3;++i) center[i]+=atom.xyz[i]; for(double& v:center)v/=static_cast<double>(atoms_.size());
  const double cy=std::cos(yaw_*std::numbers::pi/180.0), sy=std::sin(yaw_*std::numbers::pi/180.0), cp=std::cos(pitch_*std::numbers::pi/180.0), sp=std::sin(pitch_*std::numbers::pi/180.0);
  double extent=1.0; for(const auto& atom:atoms_) for(int i=0;i<3;++i) extent=std::max(extent,std::abs(atom.xyz[i]-center[i]));
  const double scale=std::min(width(),height())*0.38/extent*zoom_;
  output.reserve(static_cast<qsizetype>(atoms_.size()));
  for(size_t i=0;i<atoms_.size();++i){const auto& a=atoms_[i];const double x=a.xyz[0]-center[0],y=a.xyz[1]-center[1],z=a.xyz[2]-center[2];const double x1=cy*x+sy*z,z1=-sy*x+cy*z;const double y1=cp*y-sp*z1,z2=sp*y+cp*z1;const double perspective=1.0/(1.0+z2/(extent*8.0));output.append({{width()/2.0+pan_.x()+x1*scale*perspective,height()/2.0+pan_.y()-y1*scale*perspective},z2,std::clamp(scale*(0.12+0.012*covalentRadius(a.atomicNumber)),7.0,18.0),static_cast<int>(i)+1});}
  return output;
}

void MoleculeViewWidget::paintGL() {
  QPainter painter(this); painter.setRenderHints(QPainter::Antialiasing|QPainter::TextAntialiasing); painter.fillRect(rect(), QColor(246,249,253));
  if(atoms_.empty()){painter.setPen(QColor(105,115,130));painter.drawText(rect(),Qt::AlignCenter,tr("Gaussian 파일을 선택하면 분자가 표시됩니다.\n(Select a Gaussian file to view the molecule.)"));return;}
  const auto projected=projectedAtoms();
  QPen bondPen(QColor(78,94,116),3.5,Qt::SolidLine,Qt::RoundCap);bondPen.setJoinStyle(Qt::RoundJoin);painter.setPen(bondPen);for(const auto& bond:bonds_)painter.drawLine(projected[bond.first].point,projected[bond.second].point);
  QVector<ProjectedAtom> ordered=projected;std::sort(ordered.begin(),ordered.end(),[](const auto&a,const auto&b){return a.depth<b.depth;});
  for(const auto& item:ordered){const auto& atom=atoms_[static_cast<size_t>(item.index-1)];const bool selected=selectedAtoms_.contains(item.index);const QRectF circle(item.point.x()-item.radius,item.point.y()-item.radius,item.radius*2,item.radius*2);painter.setPen(QPen(selected?QColor(255,174,0):QColor(45,58,76),selected?4.0:1.5));painter.setBrush(elementColor(atom.symbol));painter.drawEllipse(circle);if(showIndices_){painter.setPen(atom.symbol=="H"?Qt::black:Qt::white);QFont font=painter.font();font.setPointSizeF(std::clamp(item.radius*0.62,7.0,11.0));font.setBold(true);painter.setFont(font);painter.drawText(circle,Qt::AlignCenter,QString::number(item.index));}if(selected&&mode_==InteractionMode::Geometry){const int order=selectedAtoms_.indexOf(item.index)+1;QRectF badge(item.point.x()+item.radius-5,item.point.y()-item.radius-8,18,18);painter.setPen(Qt::NoPen);painter.setBrush(QColor(255,174,0));painter.drawEllipse(badge);painter.setPen(Qt::black);painter.drawText(badge,Qt::AlignCenter,QString::number(order));}}
  if(mode_==InteractionMode::SpinDensity&&selectedAtoms_.size()==1){const int id=selectedAtoms_.front();const auto found=std::find_if(projected.begin(),projected.end(),[id](const auto& item){return item.index==id;});if(found!=projected.end()){double spin=0.0;bool hasSpin=false;for(const auto& value:spins_)if(value.atomIndex==id){spin=value.spin;hasSpin=true;break;}const auto& atom=atoms_[static_cast<size_t>(id-1)];const QString basis=QString::fromStdString(spinBasisLevel_)+(spinFallback_?QStringLiteral(" fallback"):QString());const QString text=QStringLiteral("%1(%2)\nSpin: %3\nBasis: %4").arg(QString::fromStdString(atom.symbol)).arg(id).arg(hasSpin?QString::number(spin,'f',3):QStringLiteral("N/A"),basis);QRectF box(found->point+QPointF(18,-62),QSizeF(150,58));if(box.right()>width()-8)box.moveRight(width()-8);if(box.top()<34)box.moveTop(34);painter.setPen(QPen(QColor(108,126,150),1.2));painter.setBrush(QColor(238,245,255,245));painter.drawRoundedRect(box,8,8);painter.setPen(QColor(42,55,72));painter.drawText(box.adjusted(9,5,-6,-4),Qt::AlignLeft|Qt::AlignVCenter,text);}}
  painter.setPen(QColor(75,85,100));painter.drawText(QRect(10,8,width()-20,24),Qt::AlignLeft|Qt::AlignVCenter,mode_==InteractionMode::SpinDensity?tr("스핀 밀도 모드 (Spin Density Mode)"):mode_==InteractionMode::Geometry?tr("선택 구조 모드 (Selected Geometry Mode)"):tr("분자 보기 (Molecular Viewer)"));
}

void MoleculeViewWidget::rebuildBonds(){bonds_.clear();for(size_t i=0;i<atoms_.size();++i)for(size_t j=i+1;j<atoms_.size();++j){const auto&a=atoms_[i],&b=atoms_[j];const double dx=a.xyz[0]-b.xyz[0],dy=a.xyz[1]-b.xyz[1],dz=a.xyz[2]-b.xyz[2],distance=std::sqrt(dx*dx+dy*dy+dz*dz);const double cutoff=1.22*(covalentRadius(a.atomicNumber)+covalentRadius(b.atomicNumber));if(distance>0.2&&distance<=cutoff)bonds_.append({static_cast<int>(i),static_cast<int>(j)});}}
int MoleculeViewWidget::pickAtom(const QPointF& position) const {int picked=-1;double best=1e9,bestDepth=-1e9;for(const auto& item:projectedAtoms()){const double d=QLineF(position,item.point).length();if(d<=item.radius+7.0&&(d<best||item.depth>bestDepth)){picked=item.index;best=d;bestDepth=item.depth;}}return picked;}
void MoleculeViewWidget::handleClick(const QPointF& position){const int picked=pickAtom(position);if(picked<1)return;const auto& atom=atoms_[static_cast<size_t>(picked-1)];if(mode_==InteractionMode::Geometry){if(selectedAtoms_.contains(picked))selectedAtoms_.removeAll(picked);else{if(selectedAtoms_.size()>=4)selectedAtoms_.clear();selectedAtoms_.append(picked);}emit geometrySelectionChanged(selectedAtoms_);}else{selectedAtoms_={picked};double spin=0.0;bool found=false;for(const auto& value:spins_)if(value.atomIndex==picked){spin=value.spin;found=true;break;}emit atomPicked(picked,QString::fromStdString(atom.symbol),spin,found);}update();}
void MoleculeViewWidget::mousePressEvent(QMouseEvent* event){lastMouse_=event->pos();dragging_=true;moved_=false;dragButton_=event->button();event->accept();}
void MoleculeViewWidget::mouseMoveEvent(QMouseEvent* event){if(!dragging_)return;const QPoint delta=event->pos()-lastMouse_;if(delta.manhattanLength()>2)moved_=true;if(dragButton_==Qt::RightButton||event->modifiers().testFlag(Qt::ShiftModifier))pan_+=delta;else{yaw_+=delta.x()*0.6;pitch_=std::clamp(pitch_+delta.y()*0.6,-89.0,89.0);}lastMouse_=event->pos();update();}
void MoleculeViewWidget::mouseReleaseEvent(QMouseEvent* event){if(dragging_&&!moved_&&event->button()==Qt::LeftButton)handleClick(event->position());dragging_=false;dragButton_=Qt::NoButton;event->accept();}
void MoleculeViewWidget::wheelEvent(QWheelEvent* event){zoom_=std::clamp(zoom_*std::pow(1.0015,event->angleDelta().y()),0.15,8.0);update();event->accept();}
