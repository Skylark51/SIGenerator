#include "DocxWriter.hpp"

#include <QFile>
#include <QRegularExpression>
#include <algorithm>
#include <cstdint>

namespace {
quint32 crc32(const QByteArray& data) {
  quint32 crc=0xffffffffU;
  for(const auto ch:data){crc^=static_cast<unsigned char>(ch);for(int i=0;i<8;++i)crc=(crc>>1)^((crc&1U)?0xedb88320U:0U);}
  return ~crc;
}
void u16(QFile& file,quint16 value){file.putChar(static_cast<char>(value&255));file.putChar(static_cast<char>(value>>8));}
void u32(QFile& file,quint32 value){u16(file,static_cast<quint16>(value&0xffff));u16(file,static_cast<quint16>(value>>16));}
struct Entry{QByteArray name;quint32 crc{},size{},offset{};};
QString xml(QString value){return value.replace('&',"&amp;").replace('<',"&lt;").replace('>',"&gt;").replace('"',"&quot;");}

QString run(const QString& text,bool bold=false,int halfPoints=20,const QString& vertical={}) {
  QString properties=QStringLiteral("<w:rFonts w:ascii=\"Times New Roman\" w:hAnsi=\"Times New Roman\" w:eastAsia=\"Times New Roman\" w:cs=\"Times New Roman\"/><w:sz w:val=\"%1\"/><w:szCs w:val=\"%1\"/>").arg(halfPoints);
  properties+=QStringLiteral("<w:color w:val=\"000000\"/>");
  if(bold)properties+=QStringLiteral("<w:b/><w:bCs/>");
  if(!vertical.isEmpty())properties+=QStringLiteral("<w:vertAlign w:val=\"%1\"/>").arg(vertical);
  QString content=xml(text);content.replace(QStringLiteral("\r"),QString());content.replace(QStringLiteral("\n"),QStringLiteral("</w:t><w:br/><w:t xml:space=\"preserve\">"));
  return QStringLiteral("<w:r><w:rPr>%1</w:rPr><w:t xml:space=\"preserve\">%2</w:t></w:r>").arg(properties,content);
}

QString styledRuns(const QString& text,bool bold=false,int halfPoints=20) {
  QString output; static const QRegularExpression re(QStringLiteral("([_^])(?:\\{([^{}]+)\\}|([IVX]+|[-+]?\\d+|[^_^\\s]))")); int position=0;
  auto matches=re.globalMatch(text);
  while(matches.hasNext()){const auto match=matches.next();if(match.capturedStart()>position)output+=run(text.mid(position,match.capturedStart()-position),bold,halfPoints);const auto token=match.captured(2).isEmpty()?match.captured(3):match.captured(2);output+=run(token,bold,halfPoints,match.captured(1)==QStringLiteral("_")?QStringLiteral("subscript"):QStringLiteral("superscript"));position=match.capturedEnd();}
  if(position<text.size())output+=run(text.mid(position),bold,halfPoints);
  return output.isEmpty()?run(QString(),bold,halfPoints):output;
}

QString paragraph(const QString& text,bool bold=false,int halfPoints=20,const QString& align=QStringLiteral("left"),int before=0,int after=0,const QString& style=QStringLiteral("Normal")) {
  return QStringLiteral("<w:p><w:pPr><w:pStyle w:val=\"%5\"/><w:jc w:val=\"%1\"/><w:spacing w:before=\"%2\" w:after=\"%3\" w:line=\"240\" w:lineRule=\"auto\"/></w:pPr>%4</w:p>").arg(align).arg(before).arg(after).arg(styledRuns(text,bold,halfPoints),style);
}

QString field(const QString& instruction,const QString& placeholder) {
  return QStringLiteral("<w:r><w:fldChar w:fldCharType=\"begin\" w:dirty=\"true\"/></w:r><w:r><w:instrText xml:space=\"preserve\"> %1 </w:instrText></w:r><w:r><w:fldChar w:fldCharType=\"separate\"/></w:r>%2<w:r><w:fldChar w:fldCharType=\"end\"/></w:r>").arg(xml(instruction),run(placeholder));
}

QString sequenceCaption(const QString& label,const QString& sequence,int number,const QString& title) {
  return QStringLiteral("<w:p><w:pPr><w:pStyle w:val=\"Caption\"/>%1<w:jc w:val=\"left\"/><w:spacing w:before=\"120\" w:after=\"40\"/></w:pPr>%2<w:fldSimple w:instr=\"SEQ %3 \\* ARABIC \\* CHARFORMAT\">%4</w:fldSimple>%5%6</w:p>")
    .arg(QStringLiteral("<w:outlineLvl w:val=\"1\"/>"),run(label,true),xml(sequence),run(QString::number(number),true),run(QStringLiteral(". "),true),styledRuns(title));
}

QString cell(const QString& value,bool bold,int width,bool header=false,bool first=false,int halfPoints=18) {
  const QString rule=header?QStringLiteral("<w:tcBorders><w:bottom w:val=\"single\" w:sz=\"6\" w:color=\"000000\"/></w:tcBorders>"):QString();
  return QStringLiteral("<w:tc><w:tcPr><w:tcW w:w=\"%1\" w:type=\"dxa\"/>%2<w:noWrap/><w:vAlign w:val=\"center\"/></w:tcPr><w:p><w:pPr><w:jc w:val=\"%3\"/><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/></w:pPr>%4</w:p></w:tc>")
    .arg(width).arg(rule,header?QStringLiteral("center"):(first?QStringLiteral("left"):QStringLiteral("right")),styledRuns(QString(value).replace(QRegularExpression(QStringLiteral("[\\r\\n\\x{2028}\\x{2029}]+")),QStringLiteral(" ")),bold,halfPoints));
}

QString tableXml(const si::DocumentTable& source) {
  if(source.headers.isEmpty())return {};
  const int columnCount=static_cast<int>(source.headers.size());
  const int width=9360/columnCount;
  const int halfPoints=source.section==si::DocumentSection::RelativeEnergy&&columnCount>8?16:18;
  QString table=QStringLiteral("<w:tbl><w:tblPr><w:tblW w:w=\"5000\" w:type=\"pct\"/><w:jc w:val=\"center\"/><w:tblBorders><w:top w:val=\"single\" w:sz=\"6\" w:color=\"000000\"/><w:left w:val=\"nil\"/><w:bottom w:val=\"single\" w:sz=\"6\" w:color=\"000000\"/><w:right w:val=\"nil\"/><w:insideH w:val=\"nil\"/><w:insideV w:val=\"nil\"/></w:tblBorders><w:tblLayout w:type=\"autofit\"/><w:tblCellMar><w:left w:w=\"40\" w:type=\"dxa\"/><w:right w:w=\"40\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr><w:tblGrid>");
  for(int column=0;column<columnCount;++column)table+=QStringLiteral("<w:gridCol w:w=\"%1\"/>").arg(width);
  table+=QStringLiteral("</w:tblGrid><w:tr><w:trPr><w:cantSplit/><w:tblHeader/></w:trPr>");
  for(const auto& heading:source.headers)table+=cell(heading,true,width,true,false,halfPoints);
  table+=QStringLiteral("</w:tr>");
  for(const auto& row:source.rows){
    table+=QStringLiteral("<w:tr><w:trPr><w:cantSplit/></w:trPr>");
    for(int column=0;column<columnCount;++column)table+=cell(column<row.size()?row[column]:QStringLiteral("N/A"),column==0||source.boldColumns.contains(column),width,false,column==0,halfPoints);
    table+=QStringLiteral("</w:tr>");
  }
  return table+QStringLiteral("</w:tbl>");
}

QString coordinateBody(const si::SIDocumentModel& model,int halfPoints=18) {
  QString body;
  const int digits=model.precisionOverride>0?model.precisionOverride:6;
  for(const auto& block:model.coordinates){
    body+=QStringLiteral("<w:p><w:pPr><w:keepNext/><w:spacing w:before=\"120\" w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/></w:pPr>%1</w:p>").arg(styledRuns(block.structureName,true,halfPoints));
    for(const auto& atom:block.atoms){
      const QString value=QStringLiteral("%1    %2    %3    %4").arg(QString::fromStdString(atom.symbol),-2).arg(atom.xyz[0],12,'f',digits).arg(atom.xyz[1],12,'f',digits).arg(atom.xyz[2],12,'f',digits);
      body+=paragraph(value,false,halfPoints);
    }
  }
  return body;
}

QString envelope(const QString& body,const QString& section) {
  return QStringLiteral("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><w:body>%1%2</w:body></w:document>").arg(body,section);
}
QString normalSection(){return QStringLiteral("<w:sectPr><w:footerReference w:type=\"default\" r:id=\"rIdFooter\"/><w:pgSz w:w=\"12240\" w:h=\"15840\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\"/></w:sectPr>");}

bool writePackage(const QString& path,const QString& document,QString* error) {
  const QString contentTypes=QStringLiteral("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/><Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/><Override PartName=\"/word/settings.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml\"/><Override PartName=\"/word/footer1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml\"/></Types>");
  const QString rootRels=QStringLiteral("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>");
  const QString docRels=QStringLiteral("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings\" Target=\"settings.xml\"/><Relationship Id=\"rIdFooter\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer\" Target=\"footer1.xml\"/></Relationships>");
  const QString styles=QStringLiteral("<?xml version=\"1.0\" encoding=\"UTF-8\"?><w:styles xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"Times New Roman\" w:hAnsi=\"Times New Roman\"/><w:color w:val=\"000000\"/><w:sz w:val=\"20\"/><w:szCs w:val=\"20\"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/></w:style><w:style w:type=\"paragraph\" w:styleId=\"Heading1\"><w:name w:val=\"heading 1\"/><w:basedOn w:val=\"Normal\"/><w:qFormat/><w:pPr><w:keepNext/><w:outlineLvl w:val=\"0\"/></w:pPr><w:rPr><w:b/><w:sz w:val=\"24\"/></w:rPr></w:style><w:style w:type=\"paragraph\" w:styleId=\"Title\"><w:name w:val=\"Title\"/><w:basedOn w:val=\"Normal\"/><w:qFormat/><w:rPr><w:b/><w:sz w:val=\"28\"/></w:rPr></w:style><w:style w:type=\"paragraph\" w:styleId=\"Heading2\"><w:name w:val=\"heading 2\"/><w:basedOn w:val=\"Normal\"/><w:qFormat/><w:pPr><w:keepNext/><w:outlineLvl w:val=\"1\"/></w:pPr><w:rPr><w:b/></w:rPr></w:style><w:style w:type=\"paragraph\" w:styleId=\"Caption\"><w:name w:val=\"Caption\"/><w:basedOn w:val=\"Normal\"/></w:style></w:styles>");
  const QString settings=QStringLiteral("<?xml version=\"1.0\" encoding=\"UTF-8\"?><w:settings xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:updateFields w:val=\"true\"/></w:settings>");
  const QString footer=QStringLiteral("<?xml version=\"1.0\" encoding=\"UTF-8\"?><w:ftr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:p><w:pPr><w:pStyle w:val=\"Normal\"/><w:jc w:val=\"right\"/></w:pPr>%1%2</w:p></w:ftr>").arg(run("S"),field("PAGE","1"));
  const QVector<QPair<QString,QString>> files={{QStringLiteral("[Content_Types].xml"),contentTypes},{QStringLiteral("_rels/.rels"),rootRels},{QStringLiteral("word/_rels/document.xml.rels"),docRels},{QStringLiteral("word/styles.xml"),styles},{QStringLiteral("word/settings.xml"),settings},{QStringLiteral("word/document.xml"),document},{QStringLiteral("word/footer1.xml"),footer}};
  QFile out(path);if(!out.open(QIODevice::WriteOnly|QIODevice::Truncate)){if(error)*error=out.errorString();return false;}QVector<Entry> entries;
  for(const auto& pair:files){const QByteArray name=pair.first.toUtf8(),data=pair.second.toUtf8();Entry item{name,crc32(data),static_cast<quint32>(data.size()),static_cast<quint32>(out.pos())};u32(out,0x04034b50);u16(out,20);u16(out,0);u16(out,0);u16(out,0);u16(out,0);u32(out,item.crc);u32(out,item.size);u32(out,item.size);u16(out,static_cast<quint16>(name.size()));u16(out,0);out.write(name);out.write(data);entries.append(item);}
  const quint32 central=static_cast<quint32>(out.pos());for(const auto& item:entries){u32(out,0x02014b50);u16(out,20);u16(out,20);u16(out,0);u16(out,0);u16(out,0);u16(out,0);u32(out,item.crc);u32(out,item.size);u32(out,item.size);u16(out,static_cast<quint16>(item.name.size()));u16(out,0);u16(out,0);u16(out,0);u16(out,0);u32(out,0);u32(out,item.offset);out.write(item.name);}const quint32 centralSize=static_cast<quint32>(out.pos())-central;u32(out,0x06054b50);u16(out,0);u16(out,0);u16(out,static_cast<quint16>(entries.size()));u16(out,static_cast<quint16>(entries.size()));u32(out,centralSize);u32(out,central);u16(out,0);return true;
}
}

bool DocxWriter::writeDocument(const QString& path,const si::SIDocumentModel& model,QString* error) {
  auto heading=[](const QString& text){return paragraph(text,true,24,"left",120,60,"Heading1");};
  const QString pageBreak=QStringLiteral("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>");
  QString body=paragraph("Contents",true,18);
  body+=QStringLiteral("<w:p>%1</w:p>").arg(field(QStringLiteral("TOC \\o \"1-3\" \\h \\z \\u"),QString()));
  body+=paragraph("List of Tables",true,18)+QStringLiteral("<w:p>%1</w:p>").arg(field(QStringLiteral("TOC \\c \"Table S\""),QString()));
  body+=paragraph("List of Figures",true,18)+QStringLiteral("<w:p>%1</w:p>").arg(field(QStringLiteral("TOC \\c \"Figure S\""),QString()));
  body+=pageBreak+heading(model.title==QStringLiteral("Supporting Information")?QStringLiteral("Computational Details"):model.title);
  for(const auto& text:{model.manuscriptTitle,model.authors,model.affiliations,model.correspondingEmail})
    if(!text.trimmed().isEmpty())body+=paragraph(text);
  if(!model.computationalDetails.trimmed().isEmpty())body+=paragraph(model.computationalDetails);
  body+=pageBreak;
  int figureNumber=0;
  for(const auto& caption:model.figureCaptions)if(!caption.trimmed().isEmpty())
    body+=sequenceCaption("Figure S","Figure_S",++figureNumber,caption);
  int tableNumber=0;
  const std::array sections{
    std::pair{si::DocumentSection::AbsoluteEnergy,"Absolute Energies"},
    std::pair{si::DocumentSection::RelativeEnergy,"Relative Energies"},
    std::pair{si::DocumentSection::SpinDensity,"Mulliken Spin Density"},
    std::pair{si::DocumentSection::SelectedGeometry,"Selected Geometries"},
    std::pair{si::DocumentSection::Other,"Additional Tables"}};
  for(const auto& [section,title]:sections){
    for(const auto& table:model.tables)if(table.section==section&&!table.headers.isEmpty()){
      body+=tableXml(table)+sequenceCaption("Table S","Table_S",++tableNumber,table.caption);
      if(section==si::DocumentSection::RelativeEnergy){
        if(table.headers.contains(QStringLiteral("ΔΔE^{a}")))
          body+=paragraph("^{a} Def2-TZVPP electronic energy = sum of the two previous columns.",false,16);
        if(table.headers.contains(QStringLiteral("ΔΔE_{Thermal}^{b}"))||table.headers.contains(QStringLiteral("-TΔS^{b}")))
          body+=paragraph("^{b} T = 298.15 K.",false,16);
        if(table.headers.contains(QStringLiteral("ΔG^{c}"))){
          const int precedingColumns=table.headers.indexOf(QStringLiteral("ΔG^{c}"))-1;
          const QString count=precedingColumns==6?QStringLiteral("six"):
            precedingColumns==7?QStringLiteral("seven"):
            precedingColumns==8?QStringLiteral("eight"):QString::number(precedingColumns);
          body+=paragraph(QStringLiteral("^{c} Gibbs free energy = sum of the previous %1 columns.").arg(count),false,16);
        }
        QString basis=QStringLiteral("current/default behavior");
        const QString basisMarker=QStringLiteral("Energy basis: ");
        const int basisPosition=table.caption.indexOf(basisMarker);
        if(basisPosition>=0){
          basis=table.caption.mid(basisPosition+basisMarker.size()).trimmed();
          if(basis.endsWith('.'))basis.chop(1);
        }
        body+=paragraph(QStringLiteral("Relative energies were calculated with respect to the selected reference. Energy basis: %1. Conversion factor: 1 Hartree = %2 kcal mol^{-1}.")
          .arg(basis,QString::number(si::HartreeToKcal,'f',6)),false,18,"left",80,0);
      }
    }
  }
  if(!model.referencesText.trimmed().isEmpty())body+=heading("References")+paragraph(model.referencesText);
  QString finalSection=normalSection();
  if(!model.coordinates.isEmpty()){
    body+=pageBreak+heading("Cartesian Coordinates");
    body+=QStringLiteral("<w:p><w:pPr>%1</w:pPr></w:p>").arg(normalSection());
    body+=coordinateBody(model,12);
    finalSection.replace(QStringLiteral("<w:pgSz"),QStringLiteral("<w:type w:val=\"continuous\"/><w:pgSz"));
    finalSection.replace(QStringLiteral("</w:sectPr>"),QStringLiteral("<w:cols w:num=\"3\" w:space=\"360\"/></w:sectPr>"));
  }
  return writePackage(path,envelope(body,finalSection),error);
}

bool DocxWriter::writeCoordinates(const QString& path,const si::SIDocumentModel& model,QString* error){
  return writePackage(path,envelope(paragraph("Coordinates",true,24,"left",0,60,"Heading1")+coordinateBody(model),normalSection()),error);
}
bool DocxWriter::write(const QString& path,const QString& title,const QStringList& headers,const QVector<QStringList>& rows,QString* error){si::SIDocumentModel model;model.title=title;model.tables.append({si::DocumentSection::Other,QString(),headers,rows,{}});return writeDocument(path,model,error);}
bool DocxWriter::writeTables(const QString& path,const QString& title,const QVector<Table>& tables,QString* error){si::SIDocumentModel model;model.title=title;for(const auto& table:tables)model.tables.append({si::DocumentSection::Other,table.title,table.headers,table.rows,{}});return writeDocument(path,model,error);}
