#include "DocxWriter.hpp"
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QHash>
#include <QXmlStreamReader>
#include <QtEndian>
#include <iostream>

int main(int argc,char** argv){
  QCoreApplication app(argc,argv);QString error;bool ok=true;
  auto check=[&](bool value,const char* message){if(!value){std::cerr<<"FAILED: "<<message<<'\n';ok=false;}};
  si::SIDocumentModel model;model.manuscriptTitle="Phase 1 & manuscript";model.authors="A. Author";model.affiliations="Test Laboratory";model.correspondingEmail="author@example.org";
  model.computationalDetails="Verified computational details at 298.15 K. E_SPE + (G_freq − E_freq).";model.referencesText="Reference 1";model.figureCaptions={"Reaction profile"};
  model.tables.append({si::DocumentSection::RelativeEnergy,"Markup _x ^x _{long} ^{c}",{"Structure","E_{Total}","ΔG"},{{"A","0.00","0.00"}},{1,2}});
  model.tables.append({si::DocumentSection::Validation,"Stationary-point validation of the calculated structures.",{"Structure","Imag. freq."},{{"A","0"}},{}});
  model.coordinates.append({"H_{2}O",{{8,"O",{0.0,0.0,0.0}},{1,"H",{0.9572,0.0,0.0}}}});
  const auto output=QDir::current().filePath("si-docx-smoke.docx");
  check(DocxWriter::writeDocument(output,model,&error),"DOCX write");
  QFile file(output);check(file.open(QIODevice::ReadOnly),"read package");const auto bytes=file.readAll();
  QHash<QByteArray,QByteArray> entries;
  qsizetype offset=0;
  while(offset+30<=bytes.size()&&qFromLittleEndian<quint32>(bytes.constData()+offset)==0x04034b50){
    const auto* header=bytes.constData()+offset;
    const auto size=qFromLittleEndian<quint32>(header+18);
    const auto nameSize=qFromLittleEndian<quint16>(header+26),extraSize=qFromLittleEndian<quint16>(header+28);
    const auto begin=offset+30+nameSize+extraSize;
    check(begin+size<=bytes.size(),"ZIP entry bounds");if(begin+size>bytes.size())break;
    entries.insert(bytes.mid(offset+30,nameSize),bytes.mid(begin,size));offset=begin+size;
  }
  for(const auto* name:{"word/document.xml","word/styles.xml","word/footer1.xml","word/_rels/document.xml.rels","[Content_Types].xml"}){
    check(entries.contains(name),name);
  }
  for(auto it=entries.cbegin();it!=entries.cend();++it){
    QXmlStreamReader reader(it.value());while(!reader.atEnd())reader.readNext();
    check(!reader.hasError(),it.key().constData());
  }
  const auto document=entries.value("word/document.xml"),styles=entries.value("word/styles.xml"),footer=entries.value("word/footer1.xml");
  check(document.contains("<w:pStyle w:val=\"Heading1\"")&&styles.contains("w:outlineLvl w:val=\"0\""),"semantic heading and TOC outline");
  for(const auto* name:{"Normal","Title","Heading1","Heading2","Caption"})check(styles.contains(QByteArray("w:styleId=\"")+name+"\""),name);
  check(footer.contains(" PAGE ")&&footer.contains(">S</w:t>")&&document.contains("r:id=\"rIdFooter\""),"real S + PAGE field and section reference");
  check(entries.value("word/_rels/document.xml.rels").contains("Target=\"footer1.xml\"")&&entries.value("[Content_Types].xml").contains("/word/footer1.xml"),"footer relationships and content type");
  check(document.contains("Phase 1 &amp; manuscript")&&document.contains("A. Author")&&document.contains("Test Laboratory")&&document.contains("author@example.org"),"cover metadata");
  check(document.contains("Verified computational details")&&!document.contains("Stationary-point validation")&&document.contains("Coordinates")&&document.contains("Reference 1"),"legacy document content excludes validation table");
  check(document.contains(">Contents<")&&document.contains("List of Tables")&&document.contains("List of Figures")&&!document.contains("Table of Contents"),"legacy front matter without added cover");
  check(document.indexOf("Reaction profile")<document.indexOf("<w:tbl>")&&document.indexOf("</w:tbl>")<document.indexOf("Markup")&&document.indexOf(">References<")<document.indexOf(">Cartesian Coordinates<"),"legacy figures before tables and captions below tables");
  check(document.contains("w:num=\"3\"")&&document.contains("0.957200")&&document.contains("w:sz w:val=\"12\""),"legacy three-column coordinates and six decimal places");
  check(document.contains("<w:tblHeader/>")&&document.contains("<w:cantSplit/>")&&document.contains("<w:vAlign w:val=\"center\"/>")&&!document.contains("<w:shd"),"table formatting");
  check(document.count("<w:noWrap/>")==document.count("<w:tc>")&&document.contains("<w:tblLayout w:type=\"autofit\"/>"),"all table cells prohibit line wrapping and allow columns to expand");
  check(document.contains("w:val=\"subscript\"")&&document.contains("w:val=\"superscript\""),"existing caption markup retained");
  check(!document.contains("Def2-TZVPP electronic energy =")&&!document.contains("T = 298.15 K."),"no fabricated legacy footnotes");
  std::cout<<(ok?"native DOCX smoke: PASS\n":"native DOCX smoke: FAIL\n");return ok?0:1;
}
