#pragma once
#include <QString>
#include <QVector>

namespace si {
struct NamedStructureInput {
  QString original;
  QString fileName;
  QString label;
};
// Ordinary file-name cells and explicit (label file name) pairs may be mixed.
QVector<NamedStructureInput> namedStructureInputs(const QString& text);
// Idempotent markup, shared by tables, figures, coordinate DOCX and XYZ names.
QString structureLabelMarkup(QString label);
QString formattedTextHtml(const QString& text);
}
